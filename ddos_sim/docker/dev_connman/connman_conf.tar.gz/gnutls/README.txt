Replace contents of this directory with the .deb packages listed in the Connman Dockerfile.
Required: libgcrypt11, libgnutls26, libnettle4, libhogweed2, libgnutls28, libgnutlsxx28, libgnutls-xssl0, libgnutls28-dev
