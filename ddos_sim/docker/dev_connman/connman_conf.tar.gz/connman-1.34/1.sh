#!/bin/bash
# 1.sh — connman build placeholder
apt-get install -y -q connman connmand
