Replace contents of this directory with the .deb packages listed in the Connman Dockerfile (Ubuntu trusty/xenial repos).
Required: multiarch-support, zlib1g, libpcre3, libffi6, libelfg0, libglib2.0-0/bin/dev
