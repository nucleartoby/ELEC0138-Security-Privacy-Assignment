#!/bin/bash
# 1.sh — dnsmasq build placeholder
apt-get install -y -q dnsmasq
